 realPathSuffix = '/db/carts/' + context.getVariable('proxy.pathsuffix');
context.setVariable('dynamicPath', realPathSuffix);
