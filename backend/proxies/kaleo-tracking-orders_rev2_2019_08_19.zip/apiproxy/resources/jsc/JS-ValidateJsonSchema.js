if(
    context.getVariable('trackingorder.req-order') === null ||
    context.getVariable('trackingorder.req-courier-tracking-id') === null ||
    context.getVariable('trackingorder.req-courier') === null ||
    context.getVariable('trackingorder.req-sent-date') === null ||
    context.getVariable('trackingorder.req-status') === null ||
    context.getVariable('trackingorder.req-courier-tracking-id') === null ||
    context.getVariable('trackingorder.req-origin-country') === null ||
    context.getVariable('trackingorder.req-destination-country') === null ||
    context.getVariable('trackingorder.req-destination-postal-code') === null ||
    context.getVariable('trackingorder.req-emails') === null ||
    context.getVariable('trackingorder.req-order-promised-delivery-date') === null ||
    context.getVariable('trackingorder.req-delivery-type') === null
){
    context.setVariable("triggerError", "true");
}