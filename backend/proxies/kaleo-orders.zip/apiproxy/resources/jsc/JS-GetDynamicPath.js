 realPathSuffix = '/db/orders/' + context.getVariable('proxy.pathsuffix');
context.setVariable('dynamicPath', realPathSuffix);
