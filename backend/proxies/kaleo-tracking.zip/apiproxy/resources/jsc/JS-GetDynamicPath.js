realPathSuffix = '/db/tracking-orders/' + context.getVariable('proxy.pathsuffix');
context.setVariable('dynamicPath', realPathSuffix);
